import javax.swing.*;
import java.awt.*;
import java.util.List;

public class VehicleManagementUI extends JFrame {

    public VehicleManagementUI() {
        setTitle("Vehicle Management System");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        // Add tabs
        tabbedPane.addTab("Owners", createOwnerPanel());
        tabbedPane.addTab("Vehicles", createVehiclePanel());
        tabbedPane.addTab("Maintenance", createMaintenancePanel());

        add(tabbedPane);
    }

    private JPanel createOwnerPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JPanel form = new JPanel(new GridLayout(3, 2, 5, 5));
        
        JTextField ownerIdField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField contactField = new JTextField();

        form.add(new JLabel("Owner ID:"));
        form.add(ownerIdField);
        form.add(new JLabel("Name:"));
        form.add(nameField);
        form.add(new JLabel("Contact Info:"));
        form.add(contactField);
        
        JTextArea resultArea = new JTextArea(10, 50);
        resultArea.setEditable(false);
        JButton registerButton = new JButton("Register Owner");

        panel.add(form, BorderLayout.NORTH);
        panel.add(new JScrollPane(resultArea), BorderLayout.CENTER);
        panel.add(registerButton, BorderLayout.SOUTH);

        registerButton.addActionListener(e -> {
            Owner owner = new Owner(ownerIdField.getText(), nameField.getText(), contactField.getText());
            String result = DatabaseManager.registerOwner(owner);
            resultArea.setText(result);
        });
        
        return panel;
    }

    private JPanel createVehiclePanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JPanel form = new JPanel(new GridLayout(4, 2, 5, 5));

        JTextField vehicleNumField = new JTextField();
        JTextField modelField = new JTextField();
        JTextField typeField = new JTextField();
        JTextField ownerIdField = new JTextField();

        form.add(new JLabel("Vehicle Number:"));
        form.add(vehicleNumField);
        form.add(new JLabel("Model:"));
        form.add(modelField);
        form.add(new JLabel("Type:"));
        form.add(typeField);
        form.add(new JLabel("Owner ID:"));
        form.add(ownerIdField);
        
        JTextArea resultArea = new JTextArea(10, 50);
        resultArea.setEditable(false);
        JButton addButton = new JButton("Add Vehicle");
        JButton searchButton = new JButton("Search by Number");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(searchButton);
        
        panel.add(form, BorderLayout.NORTH);
        panel.add(new JScrollPane(resultArea), BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(e -> {
            Vehicle vehicle = new Vehicle(vehicleNumField.getText(), modelField.getText(), typeField.getText(), ownerIdField.getText());
            String result = DatabaseManager.addVehicle(vehicle);
            resultArea.setText(result);
        });

        searchButton.addActionListener(e -> {
            Vehicle vehicle = DatabaseManager.findVehicleByNumber(vehicleNumField.getText());
            if (vehicle != null) {
                resultArea.setText("Found Vehicle: \n" + vehicle.toString());
            } else {
                resultArea.setText("Vehicle not found.");
            }
        });

        return panel;
    }

    private JPanel createMaintenancePanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JPanel form = new JPanel(new GridLayout(5, 2, 5, 5));
        
        JTextField vehicleNumField = new JTextField();
        JTextField detailsField = new JTextField();
        JTextField costField = new JTextField();
        JTextField serviceDateField = new JTextField();
        JTextField dueDateField = new JTextField();

        form.add(new JLabel("Vehicle Number:"));
        form.add(vehicleNumField);
        form.add(new JLabel("Service Details:"));
        form.add(detailsField);
        form.add(new JLabel("Cost:"));
        form.add(costField);
        form.add(new JLabel("Service Date (YYYY-MM-DD):"));
        form.add(serviceDateField);
        form.add(new JLabel("Next Due Date (YYYY-MM-DD):"));
        form.add(dueDateField);
        
        JTextArea resultArea = new JTextArea(10, 50);
        resultArea.setEditable(false);
        JButton addButton = new JButton("Add Log");
        JButton historyButton = new JButton("View History");
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(historyButton);

        panel.add(form, BorderLayout.NORTH);
        panel.add(new JScrollPane(resultArea), BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(e -> {
            try {
                double cost = Double.parseDouble(costField.getText());
                MaintenanceLog log = new MaintenanceLog(
                    vehicleNumField.getText(),
                    detailsField.getText(),
                    cost,
                    serviceDateField.getText(),
                    dueDateField.getText()
                );
                String result = DatabaseManager.addMaintenanceLog(log);
                resultArea.setText(result);
            } catch (NumberFormatException ex) {
                resultArea.setText("Error: Cost must be a valid number.");
            }
        });
        
        historyButton.addActionListener(e -> {
            List<MaintenanceLog> history = DatabaseManager.getMaintenanceHistory(vehicleNumField.getText());
            if (history.isEmpty()) {
                resultArea.setText("No maintenance history found for this vehicle.");
            } else {
                StringBuilder sb = new StringBuilder("Maintenance History:\n");
                for (MaintenanceLog log : history) {
                    sb.append(log.toString()).append("\n");
                }
                resultArea.setText(sb.toString());
            }
        });
        
        return panel;
    }

    public static void main(String[] args) {
        // Create the database and tables if they don't exist
        DatabaseManager.createTables();

        // Run the GUI
        SwingUtilities.invokeLater(() -> {
            VehicleManagementUI frame = new VehicleManagementUI();
            frame.setVisible(true);
        });
    }
}
