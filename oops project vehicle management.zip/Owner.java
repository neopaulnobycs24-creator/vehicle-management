public class Owner {
    private String ownerId;
    private String name;
    private String contactInfo;

    public Owner(String ownerId, String name, String contactInfo) {
        this.ownerId = ownerId;
        this.name = name;
        this.contactInfo = contactInfo;
    }

    // Getters
    public String getOwnerId() { return ownerId; }
    public String getName() { return name; }
    public String getContactInfo() { return contactInfo; }
}
