import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {

    private static final String DB_URL = "jdbc:sqlite:vehicle_management.db";

    // This static block runs once when the class is loaded.
    // It's the standard way to register a JDBC driver.
    static {
        try {
            // Explicitly load the SQLite JDBC driver class
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.err.println("FATAL: SQLite JDBC driver not found.");
            System.err.println("Please ensure the sqlite-jdbc-....jar file is in the classpath.");
            // Exit if the driver is missing, as the program cannot function.
            System.exit(1);
        }
    }

    public static Connection getConnection() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(DB_URL);
        } catch (SQLException e) {
            System.out.println("Error connecting to SQLite database: " + e.getMessage());
        }
        return conn;
    }

    // --- The rest of the class remains exactly the same ---
    // (createTables, registerOwner, addVehicle, etc.)

    public static void createTables() {
        String ownersTable = "CREATE TABLE IF NOT EXISTS owners ("
                         + " owner_id TEXT PRIMARY KEY,"
                         + " name TEXT NOT NULL,"
                         + " contact_info TEXT);";

        String vehiclesTable = "CREATE TABLE IF NOT EXISTS vehicles ("
                           + " vehicle_number TEXT PRIMARY KEY,"
                           + " model TEXT NOT NULL,"
                           + " type TEXT NOT NULL,"
                           + " status TEXT NOT NULL,"
                           + " owner_id TEXT,"
                           + " FOREIGN KEY (owner_id) REFERENCES owners(owner_id));";

        String logsTable = "CREATE TABLE IF NOT EXISTS maintenance_logs ("
                         + " log_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                         + " vehicle_number TEXT NOT NULL,"
                         + " service_details TEXT NOT NULL,"
                         + " cost REAL NOT NULL,"
                         + " service_date TEXT NOT NULL,"
                         + " next_due_date TEXT,"
                         + " FOREIGN KEY (vehicle_number) REFERENCES vehicles(vehicle_number));";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(ownersTable);
            stmt.execute(vehiclesTable);
            stmt.execute(logsTable);
        } catch (SQLException e) {
            System.out.println("Error creating tables: " + e.getMessage());
        }
    }

    public static String registerOwner(Owner owner) {
        String sql = "INSERT INTO owners(owner_id, name, contact_info) VALUES(?,?,?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, owner.getOwnerId());
            pstmt.setString(2, owner.getName());
            pstmt.setString(3, owner.getContactInfo());
            pstmt.executeUpdate();
            return "Owner registered successfully!";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    public static String addVehicle(Vehicle vehicle) {
        String sql = "INSERT INTO vehicles(vehicle_number, model, type, status, owner_id) VALUES(?,?,?,?,?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, vehicle.getVehicleNumber());
            pstmt.setString(2, vehicle.getModel());
            pstmt.setString(3, vehicle.getType());
            pstmt.setString(4, vehicle.getStatus());
            pstmt.setString(5, vehicle.getOwnerId());
            pstmt.executeUpdate();
            return "Vehicle added successfully!";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }
    
    public static Vehicle findVehicleByNumber(String vehicleNumber) {
        String sql = "SELECT * FROM vehicles WHERE vehicle_number = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, vehicleNumber);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Vehicle(
                    rs.getString("vehicle_number"),
                    rs.getString("model"),
                    rs.getString("type"),
                    rs.getString("owner_id")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error finding vehicle: " + e.getMessage());
        }
        return null;
    }

    public static String addMaintenanceLog(MaintenanceLog log) {
        String sql = "INSERT INTO maintenance_logs(vehicle_number, service_details, cost, service_date, next_due_date) VALUES(?,?,?,?,?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, log.getVehicleNumber());
            pstmt.setString(2, log.getServiceDetails());
            pstmt.setDouble(3, log.getCost());
            pstmt.setString(4, log.getServiceDate());
            pstmt.setString(5, log.getNextDueDate());
            pstmt.executeUpdate();
            return "Maintenance log added successfully!";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    public static List<MaintenanceLog> getMaintenanceHistory(String vehicleNumber) {
        List<MaintenanceLog> history = new ArrayList<>();
        String sql = "SELECT * FROM maintenance_logs WHERE vehicle_number = ? ORDER BY service_date DESC";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, vehicleNumber);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                history.add(new MaintenanceLog(
                    rs.getString("vehicle_number"),
                    rs.getString("service_details"),
                    rs.getDouble("cost"),
                    rs.getString("service_date"),
                    rs.getString("next_due_date")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error getting history: " + e.getMessage());
        }
        return history;
    }
}