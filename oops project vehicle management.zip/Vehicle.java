public class Vehicle {
    private String vehicleNumber;
    private String model;
    private String type;
    private String status;
    private String ownerId;

    public Vehicle(String vehicleNumber, String model, String type, String ownerId) {
        this.vehicleNumber = vehicleNumber;
        this.model = model;
        this.type = type;
        this.ownerId = ownerId;
        this.status = "active";
    }

    // Getters
    public String getVehicleNumber() { return vehicleNumber; }
    public String getModel() { return model; }
    public String getType() { return type; }
    public String getStatus() { return status; }
    public String getOwnerId() { return ownerId; }

    @Override
    public String toString() {
        return "Vehicle [Number=" + vehicleNumber + ", Model=" + model + ", Type=" + type + ", OwnerID=" + ownerId + "]";
    }
}
