public class MaintenanceLog {
    private String vehicleNumber;
    private String serviceDetails;
    private double cost;
    private String serviceDate;
    private String nextDueDate;

    public MaintenanceLog(String vehicleNumber, String serviceDetails, double cost, String serviceDate, String nextDueDate) {
        this.vehicleNumber = vehicleNumber;
        this.serviceDetails = serviceDetails;
        this.cost = cost;
        this.serviceDate = serviceDate;
        this.nextDueDate = nextDueDate;
    }

    // Getters
    public String getVehicleNumber() { return vehicleNumber; }
    public String getServiceDetails() { return serviceDetails; }
    public double getCost() { return cost; }
    public String getServiceDate() { return serviceDate; }
    public String getNextDueDate() { return nextDueDate; }
    
    @Override
    public String toString() {
        return "Log: " + serviceDate + " - " + serviceDetails + " (Cost: " + cost + ")";
    }
}
